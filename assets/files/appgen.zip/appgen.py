import os
import shutil
successful_titles = 0

if os.path.exists("dsiware"): shutil.rmtree("dsiware")
os.mkdir("dsiware")

for app in os.listdir(os.getcwd()):
    try:       
        for title in os.listdir(app + "/content/"):
            if title.endswith(".app"):
                print("Found app at /{}/content/{}".format(app, title))
                shutil.copy("{}/content/{}".format(app, title), "dsiware")
                os.rename("dsiware/{}".format(title), "dsiware/{}.nds".format(app))
                successful_titles = successful_titles + 1
        for title in os.listdir(app + "/data/"):
            if title.endswith(".sav"):
                print("Found save data for TitleID {}".format(app))
                shutil.copy("{}/data/{}".format(app, title), "dsiware")
                os.rename("dsiware/{}".format(title), "dsiware/{}.pub".format(app))
    except:pass 
print("Copied {} title(s) successfully".format(successful_titles))
